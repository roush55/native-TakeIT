import React from 'react'

 function AppTextInput() {
  return (
    <div>index</div>
  )
}


export default AppTextInput
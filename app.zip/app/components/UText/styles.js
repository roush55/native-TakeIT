import { StyleSheet,Platform} from 'react-native'





const styles = StyleSheet.create({
    textStyle:{
        color:'black',
        fontSize:20,
        fontFamily: "Cochin"
    },

   
       
})


export default styles


import React from 'react'
import WelcomeScreen from '../screens/welcomScreen';
import AccountScreen from '../screens/AccountScreen';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const Stack = createNativeStackNavigator();
const StackNavgator=()=>(
    <Stack.Navigator>
    <Stack.Screen  name = 'test' component={WelcomeScreen}/>
    <Stack.Screen  name = 'account' component={AccountScreen}/>
   
    
    </Stack.Navigator>
  )
export default function AppNavigator() {
  return (
    <StackNavgator/>
  )
}

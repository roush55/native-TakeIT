import React from 'react'
import { StyleSheet, Text, View,FlatList } from 'react-native'
import Screen from '../../components/Screen'
import ListItem from '../../components/ListItem/ListItem'
import styles from './styles'
import Icon from '../../components/Icon'
import Separator from '../../components/separator'
import colors from '../../config/colors'

export const list=[

    {
    title:'T1',
    icon:{name:'envelope',color:'#000'},
    
    },
    
    {
        title:'T2',
        icon:{name:'envelope',color:'#000'},
        
        },
    
    ]

 function AccountScreen() {
    return (
        <Screen style={styles.screen}>
<View style={styles.container}>
       
            </View>

            <View style={styles.container}>

            <FlatList
        data={list}
        keyExtractor={menuItem => menuItem.title}
        renderItem={({item})=>(

            <ListItem
            title={item.title}
            IconComponenet={<Icon name={item.icon.name} backgroundColor={item.icon.color}  color={'#fff'}/>}
            onPress={()=>console.log('hhhhh')}
            
            />
        )}
        ItemSeparatorComponent={()=><Separator/>}
       
      
        />
            </View>
            <ListItem
            title={'logOut'}
            IconComponenet={<Icon name='sign-out-alt' backgroundColor={colors.primary}  color={'#fff'}/>}
            onPress={()=>console.log('hhhhh')}
            />

        </Screen>
    )
}

export default AccountScreen


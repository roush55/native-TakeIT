
 
 export default {
    white:'#fff',
    meduim:'#6e6969',
    primary:'#4ECDC4',
    light:'#f8f4f4',
    primary:'#4ECDC4'

 };
 